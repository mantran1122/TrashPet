#ifndef EATDIALOG_H
#define EATDIALOG_H

#include <QDialog>
#include "recyclebinmanager.h"

class QRadioButton;
class QLabel;

class EatDialog : public QDialog {
    Q_OBJECT
public:
    enum class SortOrder { OldestFirst, LargestFirst };

    // items: toàn bộ item trong recycle bin (bao gồm cả > 1GB)
    // currentHunger: chỉ số đói hiện tại [0, 100]
    explicit EatDialog(const QVector<RecycleBinManager::Item> &items,
                       int currentHunger,
                       QWidget *parent = nullptr);

    SortOrder sortOrder() const;

private:
    QRadioButton *m_radioOldest  = nullptr;
    QRadioButton *m_radioLargest = nullptr;
};

#endif // EATDIALOG_H
