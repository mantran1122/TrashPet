#include "eatdialog.h"
#include "hungerconfig.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QRadioButton>
#include <QPushButton>
#include <QGroupBox>
#include <QScrollArea>
#include <algorithm>

namespace {
// Format dung lượng bytes → chuỗi dễ đọc
QString formatSize(quint64 bytes) {
    if (bytes >= 1024ULL * 1024 * 1024)
        return QString("%1 GB").arg(bytes / (1024.0 * 1024.0 * 1024.0), 0, 'f', 1);
    if (bytes >= 1024 * 1024)
        return QString("%1 MB").arg(bytes / (1024.0 * 1024.0), 0, 'f', 1);
    if (bytes >= 1024)
        return QString("%1 KB").arg(bytes / 1024.0, 0, 'f', 1);
    return QString("%1 B").arg(bytes);
}

int hungerMbForBytes(quint64 bytes) {
    constexpr quint64 kOneMb = 1024ULL * 1024ULL;
    return static_cast<int>((bytes + kOneMb - 1) / kOneMb);
}
}

EatDialog::EatDialog(const QVector<RecycleBinManager::Item> &items,
                     int currentHunger,
                     QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("🗑️ Cho TrashPet ăn rác");
    setMinimumWidth(400);

    setStyleSheet(R"(
        QDialog  { background-color: #1e1e2e; color: #e0e0e0; }
        QLabel   { color: #e0e0e0; }
        QGroupBox{ color: #aaaaaa; border: 1px solid #3a3a4e; border-radius: 6px;
                   margin-top: 8px; padding: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }
        QRadioButton { color: #e0e0e0; spacing: 6px; }
        QRadioButton::indicator { width: 14px; height: 14px; }
        QPushButton {
            background-color: #5b6fed; color: white; border: none;
            border-radius: 8px; padding: 8px 18px; font-weight: bold;
        }
        QPushButton:hover { background-color: #6f81f0; }
        QPushButton#cancelBtn {
            background-color: #3a3a4e; color: #aaaaaa;
        }
        QPushButton#cancelBtn:hover { background-color: #4a4a5e; }
    )");

    // Tách items theo kích thước
    QVector<RecycleBinManager::Item> eligible;  // có thể ăn được
    QVector<RecycleBinManager::Item> tooBig;    // > 1 GB, sẽ skip

    quint64 totalBytes = 0;
    for (const auto &it : items) {
        totalBytes += it.sizeBytes;
        if (it.sizeBytes > HungerCfg::kMaxFileBytes)
            tooBig.append(it);
        else
            eligible.append(it);
    }

    std::sort(eligible.begin(), eligible.end(),
              [](const RecycleBinManager::Item &a, const RecycleBinManager::Item &b) {
                  return a.deletedAt < b.deletedAt;
              });

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(10);
    mainLayout->setContentsMargins(16, 16, 16, 16);

    // Header: trạng thái đói
    QString hungerEmoji = currentHunger >= HungerCfg::kThresholdHungry ? "🥺🥺🥺"
                        : currentHunger >= HungerCfg::kThresholdMild   ? "🥺"
                                                                        : "🐌";
    auto *lblHunger = new QLabel(
        QString("%1 TrashPet đang đói: <b>%2/100</b>")
            .arg(hungerEmoji).arg(currentHunger), this);
    lblHunger->setStyleSheet("font-size: 14px;");
    mainLayout->addWidget(lblHunger);

    // Thông tin thùng rác
    auto *lblInfo = new QLabel(
        QString("Thùng rác: <b>%1 file</b> (%2)")
            .arg(items.size()).arg(formatSize(totalBytes)), this);
    mainLayout->addWidget(lblInfo);

    // Skip list
    if (!tooBig.isEmpty()) {
        auto *grpSkip = new QGroupBox(
            QString("%1 file > 1 GB sẽ bị skip:").arg(tooBig.size()), this);
        auto *skipLayout = new QVBoxLayout(grpSkip);
        skipLayout->setSpacing(2);
        for (const auto &it : tooBig) {
            auto *lbl = new QLabel(
                QString("  • %1  (%2)").arg(it.displayName, formatSize(it.sizeBytes)), grpSkip);
            lbl->setStyleSheet("color: #ff8888; font-size: 12px;");
            skipLayout->addWidget(lbl);
        }
        mainLayout->addWidget(grpSkip);
    }

    // Thứ tự ăn
    auto *grpOrder = new QGroupBox("Thứ tự ăn:", this);
    auto *orderLayout = new QVBoxLayout(grpOrder);
    m_radioOldest  = new QRadioButton("🕐 Cũ nhất trước",  grpOrder);
    m_radioLargest = new QRadioButton("📦 Lớn nhất trước", grpOrder);
    m_radioOldest->setChecked(true);
    orderLayout->addWidget(m_radioOldest);
    orderLayout->addWidget(m_radioLargest);
    mainLayout->addWidget(grpOrder);

    // Cảnh báo xóa vĩnh viễn: hiển thị đúng tổng dung lượng THỰC sẽ mất,
    // không phải phần hunger được cap — vì file luôn bị xóa nguyên vẹn.
    auto *lblEstimate = new QLabel(this);
    lblEstimate->setWordWrap(true);
    lblEstimate->setStyleSheet("color: #ff8888; font-size: 12px; font-weight: bold;");
    mainLayout->addWidget(lblEstimate);
    auto *lblHungerNote = new QLabel(this);
    lblHungerNote->setStyleSheet("color: #7ee787; font-size: 12px;");
    mainLayout->addWidget(lblHungerNote);

    auto updateEstimate = [this, eligible, currentHunger, lblEstimate, lblHungerNote]() {
        QVector<RecycleBinManager::Item> sorted = eligible;
        if (m_radioLargest->isChecked()) {
            std::sort(sorted.begin(), sorted.end(),
                      [](const RecycleBinManager::Item &a, const RecycleBinManager::Item &b) {
                          return a.sizeBytes > b.sizeBytes;
                      });
        } else {
            std::sort(sorted.begin(), sorted.end(),
                      [](const RecycleBinManager::Item &a, const RecycleBinManager::Item &b) {
                          return a.deletedAt < b.deletedAt;
                      });
        }

        int hungerLeftForOrder = currentHunger;
        quint64 totalBytesForOrder = 0;
        int hungerConsumedForOrder = 0;
        int filesForOrder = 0;
        for (const auto &it : sorted) {
            if (hungerLeftForOrder <= 0) break;
            const int mb = hungerMbForBytes(it.sizeBytes);
            const int consume = std::min(mb, hungerLeftForOrder);
            totalBytesForOrder += it.sizeBytes;
            hungerConsumedForOrder += consume;
            hungerLeftForOrder -= consume;
            filesForOrder++;
        }

        lblEstimate->setText(
            QString("⚠️ Sẽ xóa vĩnh viễn %1 file — tổng ~%2 (không thể khôi phục)")
                .arg(filesForOrder).arg(formatSize(totalBytesForOrder)));
        lblHungerNote->setText(
            QString("Hunger giảm %1 MB (phần dư chuyển thành tăng kích thước pet)")
                .arg(hungerConsumedForOrder));
    };
    connect(m_radioOldest, &QRadioButton::toggled, this, updateEstimate);
    connect(m_radioLargest, &QRadioButton::toggled, this, updateEstimate);
    updateEstimate();

    if (eligible.isEmpty()) {
        auto *lblNoEat = new QLabel("(Không có file nào phù hợp để ăn)", this);
        lblNoEat->setStyleSheet("color: #ff8888;");
        mainLayout->addWidget(lblNoEat);
    }

    // Buttons
    auto *btnRow   = new QHBoxLayout();
    auto *btnEat   = new QPushButton("🍴 Cho ăn!", this);
    auto *btnCancel = new QPushButton("Hủy", this);
    btnCancel->setObjectName("cancelBtn");
    btnRow->addWidget(btnEat);
    btnRow->addWidget(btnCancel);
    mainLayout->addLayout(btnRow);

    btnEat->setEnabled(!eligible.isEmpty());

    connect(btnEat,    &QPushButton::clicked, this, &QDialog::accept);
    connect(btnCancel, &QPushButton::clicked, this, &QDialog::reject);
}

EatDialog::SortOrder EatDialog::sortOrder() const {
    return m_radioLargest->isChecked() ? SortOrder::LargestFirst
                                       : SortOrder::OldestFirst;
}
